## 1.0 2019-02-15 <dave at tiredofit dot ca>

* Initial Release
* Alpine 3.9
* NodeJS 11

